package com.example.taxseehelper

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class OrderNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Privasi: hanya mencatat paket dan waktu kedatangan di log lokal Android; tidak membaca isi pesan.
        Log.i("TaxseeHelper", "Notification received: package=${sbn.packageName}, time=${sbn.postTime}")
    }
}

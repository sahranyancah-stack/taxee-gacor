# Taxsee Driver Helper 1.0 (Android starter project)

Companion app for connection/GPS checks and notification-listener permission status. It does NOT modify Maxim/Taxsee, read notification contents, intercept orders, automate acceptance, or promise faster dispatch.

## Build
1. Install Android Studio (current stable).
2. Open this project folder.
3. Allow Gradle sync; install SDK 35 if prompted.
4. Build > Build APK(s).
5. Install on Android 8+.

Permissions: location (while app is in use), and optional notification listener permission enabled manually in Android settings. GPS status can be refreshed by tapping the GPS button.

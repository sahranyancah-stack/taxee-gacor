package com.example.taxseehelper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var gpsText: TextView
    private lateinit var networkText: TextView
    private lateinit var notifText: TextView
    private lateinit var locationManager: LocationManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 40, 36, 36); gravity = Gravity.CENTER_HORIZONTAL }
        val title = TextView(this).apply { text = "Taxsee Driver Helper 1.0"; textSize = 24f; gravity = Gravity.CENTER; setPadding(0,0,0,24) }
        gpsText = statusText("GPS: belum dipantau")
        networkText = statusText("Jaringan: memeriksa…")
        notifText = statusText("Pemantau notifikasi: status belum diperiksa")
        root.addView(title); root.addView(gpsText); root.addView(networkText); root.addView(notifText)
        root.addView(makeButton("Periksa jaringan", ::checkNetwork))
        root.addView(makeButton("Mulai pantau GPS", ::startGps))
        root.addView(makeButton("Aktifkan pemantau notifikasi", ::openNotificationSettings))
        root.addView(makeButton("Buka pengaturan aplikasi", { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = android.net.Uri.parse("package:$packageName") }) }))
        root.addView(TextView(this).apply { text = "Aplikasi pendamping ini tidak mengubah, mengakses, atau mengendalikan sistem order Maxim. Notifikasi dipantau hanya setelah izin diberikan."; textSize = 14f; setPadding(0,24,0,0) })
        setContentView(root)
        checkNetwork(); checkNotificationPermission()
    }

    private fun statusText(s: String) = TextView(this).apply { text = s; textSize = 18f; setPadding(0,16,0,16) }
    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }

    private fun checkNetwork() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val transport = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Data seluler"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "Tidak diketahui"
        }
        networkText.text = "Jaringan: ${if (connected) "terhubung ($transport)" else "tidak terhubung"}"
    }

    private fun startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 11); return
        }
        try {
            val provider = if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            locationManager.requestLocationUpdates(provider, 3000L, 2f, object : LocationListener {
                override fun onLocationChanged(location: Location) { gpsText.text = "GPS: akurasi ±${location.accuracy.toInt()} m\nUpdate lokasi: diterima" }
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) { gpsText.text = "GPS: provider dimatikan" }
            })
            gpsText.text = "GPS: menunggu pembaruan lokasi…"
        } catch (e: Exception) { gpsText.text = "GPS: gagal memulai (${e.localizedMessage})" }
    }

    private fun openNotificationSettings() { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
    private fun checkNotificationPermission() {
        val enabled = android.provider.Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        notifText.text = "Pemantau notifikasi: ${if (enabled) "aktif" else "belum diizinkan"}"
    }
    override fun onResume() { super.onResume(); checkNetwork(); checkNotificationPermission() }
}
